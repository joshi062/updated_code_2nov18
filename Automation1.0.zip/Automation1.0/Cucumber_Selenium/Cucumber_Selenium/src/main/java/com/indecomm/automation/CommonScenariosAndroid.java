package com.indecomm.automation;

import java.rmi.server.ObjID;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.indecomm.data.JSONProcessor;
import com.indecomm.dto.AutomationDTO;
import com.indecomm.fixtures.AbstractAutomationFixtures;
import com.indecomm.fixtures.IOSAutomationFixture;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class CommonScenariosAndroid {

	private AppiumDriver driver;
	AbstractAutomationFixtures abstractAutomationFixtures;
	ElementRepository elementRepository;
	String propetyPath;
	JSONProcessor usertJsonObject, userData;;
	JSONObject userInfoJSONObject;
	AutomationDTO objDTO;
	String userName, userPwd, dirPath, sheetName;
	XSSFWorkbook userWorkbook;
	XSSFSheet userDataSheet;

	public CommonScenariosAndroid(AppiumDriver<MobileElement> driver) {
		this.driver = driver;

		System.out.println(":: Start redirecting on login page ::");

		dirPath = System.getProperty("user.dir");
		propetyPath = dirPath + "/feedFiles/locator.properties";

		elementRepository = new ElementRepository(propetyPath);

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);

		objDTO = new AutomationDTO();
	}

	public void AppLogin(String platform) throws InterruptedException {

		// READING DATA FROM DTO JSON - to work with this uncomment "userInfoJSONObject"

		// userInfoJSONObject = objDTO.getDataJson("/feedFiles/userData.json");

		if (userInfoJSONObject != null) {
			userName = (((JSONObject) userInfoJSONObject.get("user2")).get("username")).toString();
			userPwd = (((JSONObject) userInfoJSONObject.get("user2")).get("password")).toString();

		}

		// READING DATA FROM EXCEL

		userWorkbook = objDTO.getDataExcel(dirPath + "/feedFiles/userData.xlsx");
		Row userRow = userWorkbook.getSheet(sheetName).getRow(0);
		if (userRow != null) {

			System.out.println(userRow.getCell(0).toString() + " CELL " + userRow.getCell(1).toString());
		}

		Thread.sleep(6000);
		WebElement continueBtn = this.driver.findElementById(elementRepository.getPropertyByTag("continueBtn"));
		continueBtn.click();

		Thread.sleep(6000);
		WebElement userNameFld = this.driver.findElementById(elementRepository.getPropertyByTag("userNameFld"));
		userNameFld.click();
		Thread.sleep(6000);
		userNameFld.sendKeys(userName);
		Thread.sleep(3000);

		WebElement passwordFld = this.driver.findElementById(elementRepository.getPropertyByTag("passwordFld"));
		passwordFld.click();
		passwordFld.sendKeys(userPwd);
		Thread.sleep(6000);

		WebElement loginBtn = this.driver.findElementById(elementRepository.getPropertyByTag("loginBtn"));
		loginBtn.click();
		Thread.sleep(5000);

		new WebDriverWait(driver, 10).until(
				ExpectedConditions.presenceOfElementLocated(By.id(elementRepository.getPropertyByTag("applianceTab"))));

		WebElement applianceTab = this.driver.findElementById(elementRepository.getPropertyByTag("applianceTab"));
		applianceTab.click();
		Thread.sleep(5000);

//		WebElement el6 =  this.driver.findElementByXPath("//*[@class='android.view.View' and contains(text(),'MY WASHER')]");
//		el6.click();
//		Thread.sleep(3000);

		/*
		 * Click on Continue button to redirect loginpage
		 */
		/*
		 * Thread.sleep(5000); if(btnContinue.isDisplayed())
		 * System.out.println("btnContinue.-----------------------");
		 * 
		 * //abstractAutomationFixtures.waitForPageToLoad(driver, btnContinue, 10);
		 * btnContinue.click();
		 */

		// Wait until find Element

		// abstractAutomationFixtures.waitForElement(driver, btnLogin, 10);

		/*
		 * On Login page to enter credential
		 */

		// abstractAutomationFixtures.sendText(txtUserName,
		// "devemerald@electrolux.com");
		//// abstractAutomationFixtures.sendText(txtPassword, "Bhasha23@");
		// abstractAutomationFixtures.click(btnLogin);
	}
}
