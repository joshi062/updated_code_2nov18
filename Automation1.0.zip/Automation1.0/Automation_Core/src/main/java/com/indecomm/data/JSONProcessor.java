package com.indecomm.data;

import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.indecomm.util.AutomationUtility;



//THIS CLASS IS NOT IN USE-------------------------
public class JSONProcessor implements DataProcessor {
	JSONObject jsonObject;

	public JSONProcessor() {

	}

	public Object getData() {

		return this.jsonObject;
	}

	public JSONObject getJSONObject(String name) {
		JSONObject jObj = (JSONObject) jsonObject.get(name);
		return jObj;
	}

	public String getAttribute(String key) {
		String value = (String) jsonObject.get(key);
		return value;
	}

	public String getAttribute(JSONObject json, String key) {
		String value = (String) json.get(key);
		return value;
	}

	// Add methods required to get an Array if any.
	public void processData(String fileName) {

		JSONParser jsonParser = null;
		try {
			System.out.println("fileName --" + fileName);

			this.jsonObject = AutomationUtility.readJSON(fileName);

		} catch (Exception exc) {
			// Call the logger method to log the exception.
			System.out.println("fileName --" + exc);
		}

	}

}
